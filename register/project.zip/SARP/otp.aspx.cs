﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using System.Net;
using System.Data;
using System.Data.SqlClient;
using System.Collections.Specialized;
public partial class otp : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        SqlConnection con = new SqlConnection("Data Source=.\\SQLEXPRESS;AttachDbFilename=C:\\Users\\Rishikesh\\Documents\\Visual Studio 2010\\WebSites\\SARP\\App_Data\\registration.mdf;Integrated Security=True;User Instance=True");
        SqlCommand cmd = new SqlCommand();

    }
    protected void Unnamed1_Click(object sender, EventArgs e)
    {
        string destinationaddr = "91" + TextBox1.Text;
        string message = "Hi " + TextBox1.Text + " , You Have Been Registered For The Contest. Thanks!!";

        String message1 = HttpUtility.UrlEncode(message);
        using (var wb = new WebClient())
        {
            byte[] response = wb.UploadValues("https://api.textlocal.in/send/", new NameValueCollection()
                {
                {"apikey" , "TIaEl9Xkapc-sfLbl5FhQRzjeoFqRoGhx05DrH63JZ"},
                {"numbers" , destinationaddr},
                {"message" , message1},
                {"sender" , "TXTLCL"}
                });
            string result = System.Text.Encoding.UTF8.GetString(response);
            savedata();
            Label2.Text = "You Have Successfully Registered";
        }
    }
    public void savedata()
    {
        String query = "insert into otp(number) values('" + TextBox1.Text + "')";
        String mycon = "Data Source=.\\SQLEXPRESS;AttachDbFilename=C:\\Users\\Rishikesh\\Documents\\Visual Studio 2010\\WebSites\\SARP\\App_Data\\registration.mdf;Integrated Security=True;User Instance=True";
        SqlConnection con = new SqlConnection(mycon);
        con.Open();
        SqlCommand cmd = new SqlCommand();
        cmd.CommandText = query;
        cmd.Connection = con;
        cmd.ExecuteNonQuery();
        Label2.Text = "You Have Successfully Registered For Contest - Thank You";


    }

}