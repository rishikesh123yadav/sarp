﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using System.Configuration;
public partial class cl : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        if (IsPostBack)
        {
            SqlConnection conn = new SqlConnection(ConfigurationManager.ConnectionStrings["RegistrationConnectionString"].ConnectionString);
            conn.Open();
            string checkuser = "select count (*) from cl where sid = '" + sid.Text + "'";
            SqlCommand com = new SqlCommand(checkuser, conn);
            int temp = Convert.ToInt32(com.ExecuteScalar().ToString());
            if (temp == 1)
            {
                Label1.Text = "Student Alredy Present.";
                conn.Close();
            }
        }
    }
    protected void Button1_Click(object sender, EventArgs e)
    {
        try
        {


            SqlConnection conn = new SqlConnection(ConfigurationManager.ConnectionStrings["RegistrationConnectionString"].ConnectionString);
            conn.Open();
            string insertQuery = "insert into cl (sid) values(@sid)";
            SqlCommand com = new SqlCommand(insertQuery, conn);
            com.Parameters.AddWithValue("@sid", sid.Text);
            com.ExecuteNonQuery();
            Label1.Text = "ID successfully Added.";
            conn.Close();
        }
        catch (Exception ex)
        {
            Response.Write("Error : " + ex.ToString());
        }

    }
    protected void GridView1_RowCommand(object sender, GridViewCommandEventArgs e)
    {

        if (e.CommandName == "Delete Row")
        {
            int crow;
            crow = Convert.ToInt32(e.CommandArgument.ToString());
            string sid = GridView1.Rows[crow].Cells[0].Text;
            Response.Write(sid);
            deleterowdata(sid);
        }
    }
    private void deleterowdata(String sid)
    {
        SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["RegistrationConnectionString"].ConnectionString);
        String deletedata = "delete from cl where sid=" + Convert.ToInt16(sid);
        con.Open();
        SqlCommand cmd = new SqlCommand();
        cmd.CommandText = deletedata;
        cmd.Connection = con;
        cmd.ExecuteNonQuery();
        con.Close();

    }
}