﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using System.Configuration;
public partial class Login : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {

    }
    protected void Button1_Click(object sender, EventArgs e)
    {

      SqlConnection conn = new SqlConnection(ConfigurationManager.ConnectionStrings["RegistrationConnectionString"].ConnectionString);
            conn.Open();
            string checkuser = "select count (*) from login where UserName = '" + UserName.Text + "'";
            SqlCommand com = new SqlCommand(checkuser, conn);
            int temp = Convert.ToInt32(com.ExecuteScalar().ToString());
            conn.Close();
            if (temp == 1)
            {
                conn.Open();
                string checkPasswordQuery = "select password from login where UserName = '" + UserName.Text + "'";
                SqlCommand passComm = new SqlCommand(checkPasswordQuery, conn);
                string password = passComm.ExecuteScalar().ToString().Replace(" ", "");
                String username = UserName.Text;
                if (username == "cl123" )
                {
                    Response.Redirect("cl.aspx");
                }else
                    if (username == "cl123")
                    {
                        Response.Redirect("cl.aspx");
                    }
                    else
                        if (username == "dl123")
                        {
                            Response.Redirect("dl.aspx");
                        }
                        else
                            if (username == "co123")
                            {
                                Response.Redirect("co.aspx");
                            }
                            else
                                if (username == "id123")
                                {
                                    Response.Redirect("id.aspx");
                                }
                                else
                if (password == Password.Text)
                {
                    Session["New"] = UserName.Text;
                    Response.Redirect("Registration.aspx");
                }
                else
                {
                    Response.Write("Username or Password is not correct");
                }
            }
            else
            {
                Response.Write("Username or Password  is not correct");
            }
}
}
