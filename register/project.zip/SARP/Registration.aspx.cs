﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using System.Configuration;
public partial class Registration : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        if (Session["New"] != null)
        {
            Label.Text += Session["New"].ToString();
        }
        else
        {
            Response.Redirect("Login.aspx");
        }

        //This code check if user alredy exist
        if (!IsPostBack)
        {
            SqlConnection conn = new SqlConnection(ConfigurationManager.ConnectionStrings["RegistrationConnectionString"].ConnectionString);
            conn.Open();
            string checkuser = "select count (*) from register where sid = '" + sid.Text + "'";
            SqlCommand com = new SqlCommand(checkuser, conn);
            int temp = Convert.ToInt32(com.ExecuteScalar().ToString());
            if (temp == 1)
            {
                Response.Write("User already Exist");
                conn.Close();
            }
        }
        //End of cheching porson
    }

    protected void Button1_Click(object sender, EventArgs e)
    {
        try
        {
           

            SqlConnection conn = new SqlConnection(ConfigurationManager.ConnectionStrings["RegistrationConnectionString"].ConnectionString);
            conn.Open();
            string insertQuery = "insert into register (UserName,sid,fname,course,branch,semester,dob,address,phone,Email) values(@un,@sid,@fname,@course,@branch,@semester,@dob,@address,@phone,@email)";
            SqlCommand com = new SqlCommand(insertQuery, conn);
            com.Parameters.AddWithValue("@un", un.Text);
            com.Parameters.AddWithValue("@sid", sid.Text);
            com.Parameters.AddWithValue("@fname", fname.Text);
            com.Parameters.AddWithValue("@course", course.Text);
            com.Parameters.AddWithValue("@branch", branch.Text);
            com.Parameters.AddWithValue("@semester", semester.Text);
            com.Parameters.AddWithValue("@dob", dob.Text);
            com.Parameters.AddWithValue("@address", address.Text);
            com.Parameters.AddWithValue("@phone", phone.Text);
            com.Parameters.AddWithValue("@email", email.Text);
            com.ExecuteNonQuery();
            Label1.Text = "Registration successfull";
            conn.Close();
        }
        catch (Exception ex)
        {
            Response.Write("Error : " + ex.ToString());
        }

    }

}